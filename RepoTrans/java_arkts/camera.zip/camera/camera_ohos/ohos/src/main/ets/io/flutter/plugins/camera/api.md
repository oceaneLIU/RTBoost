

android => ohos
CamcorderProfile => media.AVRecorderProfile