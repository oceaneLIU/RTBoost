## NEXT

* Updates minimum supported SDK version to Flutter 3.7/Dart 2.19.

## 0.5.0+2

* Adjusts SDK checks for better testability.

## 0.5.0+1

* Bumps androidx.annotation:annotation from 1.5.0 to 1.6.0.
* Adds a dependency on kotlin-bom to align versions of Kotlin transitive dependencies.

## 0.5.0

* Implements file_selector_platform_interface for Android.
