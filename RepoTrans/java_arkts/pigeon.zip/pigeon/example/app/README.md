# pigeon_example_app

This demonstrates using Pigeon for platform communication directly in an
application, rather than in a plugin.

To update the generated code, run:
```sh
dart run pigeon --input pigeons/messages.dart
```
