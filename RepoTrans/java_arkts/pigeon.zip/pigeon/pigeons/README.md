This directory contains Pigeon API definitions used to generate code for tests.

Please do not add new files to this directory unless absolutely necessary;
most additions should go into core_tests.dart. See
https://github.com/flutter/flutter/issues/115168 for context.
