# alternate_language_test_plugin

Tests for languages not covered by `test_plugin`.
See [the `platform_tests` README](../README.md) for details.

To run these tests, use [`test.dart`](../tool/test.dart)
