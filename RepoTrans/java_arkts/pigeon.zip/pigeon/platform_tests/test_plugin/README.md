# test_plugin

Tests for default plugin languages.
See [the `platform_tests` README](../README.md) for details.
