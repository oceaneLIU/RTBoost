// Copyright 2013 The Flutter Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// There is intentionally no code here; tests use generated Pigeon APIs
// directly, as wrapping them in a plugin would just add maintenance burden
// when changing tests.
