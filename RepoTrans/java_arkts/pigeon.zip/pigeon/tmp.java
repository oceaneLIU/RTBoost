public class tmp {

    tCreate(
            instanceIdArg: number,
            isCaptureEnabledArg: boolean,
            acceptTypesArg: string[],
            modeArg: FileChooserMode,
            //filenameHintArg:string,
            callback: Reply<void>
    ) {
    const channel: BasicMessageChannel<ESObject> = new BasicMessageChannel<ESObject>(
                this.binaryMessenger,
                "dev.flutter.pigeon.webview_flutter_ohos.FileChooserParamsFlutterApi.create",
                FileChooserParamsFlutterApi.getCodec()
        );
        channel.send(
                [instanceIdArg, isCaptureEnabledArg, acceptTypesArg, modeArg],
                (channelReply: ESObject) => callback.reply(null)
    );
    }
}
