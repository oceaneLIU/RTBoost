# video_player_example

Demonstrates how to use the video_player plugin.
