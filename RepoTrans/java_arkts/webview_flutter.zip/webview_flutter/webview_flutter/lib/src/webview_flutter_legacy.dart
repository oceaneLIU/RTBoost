// Copyright 2013 The Flutter Authors. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

export 'package:webview_flutter_android/src/webview_flutter_android_legacy.dart';
export 'package:webview_flutter_wkwebview/src/webview_flutter_wkwebview_legacy.dart';
export 'package:webview_flutter_ohos/src/webview_flutter_ohos_legacy.dart';

export 'legacy/platform_interface.dart';
export 'legacy/webview.dart';
