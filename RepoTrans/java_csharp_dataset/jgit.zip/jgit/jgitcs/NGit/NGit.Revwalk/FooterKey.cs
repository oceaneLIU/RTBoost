/*
This code is derived from jgit (http://eclipse.org/jgit).
Copyright owners are documented in jgit's IP log.

This program and the accompanying materials are made available
under the terms of the Eclipse Distribution License v1.0 which
accompanies this distribution, is reproduced below, and is
available at http://www.eclipse.org/org/documents/edl-v10.php

All rights reserved.

Redistribution and use in source and binary forms, with or
without modification, are permitted provided that the following
conditions are met:

- Redistributions of source code must retain the above copyright
  notice, this list of conditions and the following disclaimer.

- Redistributions in binary form must reproduce the above
  copyright notice, this list of conditions and the following
  disclaimer in the documentation and/or other materials provided
  with the distribution.

- Neither the name of the Eclipse Foundation, Inc. nor the
  names of its contributors may be used to endorse or promote
  products derived from this software without specific prior
  written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND
CONTRIBUTORS "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES,
INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES
OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT
NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT,
STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF
ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*/

using NGit;
using Sharpen;

namespace NGit.Revwalk
{
	/// <summary>
	/// Case insensitive key for a
	/// <see cref="FooterLine">FooterLine</see>
	/// .
	/// </summary>
	public sealed class FooterKey
	{
		/// <summary>
		/// Standard
		/// <code>Signed-off-by</code>
		/// 
		/// </summary>
		public static readonly NGit.Revwalk.FooterKey SIGNED_OFF_BY = new NGit.Revwalk.FooterKey
			("Signed-off-by");

		/// <summary>
		/// Standard
		/// <code>Acked-by</code>
		/// 
		/// </summary>
		public static readonly NGit.Revwalk.FooterKey ACKED_BY = new NGit.Revwalk.FooterKey
			("Acked-by");

		/// <summary>
		/// Standard
		/// <code>CC</code>
		/// 
		/// </summary>
		public static readonly NGit.Revwalk.FooterKey CC = new NGit.Revwalk.FooterKey("CC"
			);

		private readonly string name;

		internal readonly byte[] raw;

		/// <summary>Create a key for a specific footer line.</summary>
		/// <remarks>Create a key for a specific footer line.</remarks>
		/// <param name="keyName">name of the footer line.</param>
		public FooterKey(string keyName)
		{
			name = keyName;
			raw = Constants.Encode(keyName.ToLower());
		}

		/// <returns>name of this footer line.</returns>
		public string GetName()
		{
			return name;
		}

		public override string ToString()
		{
			return "FooterKey[" + name + "]";
		}
	}
}
